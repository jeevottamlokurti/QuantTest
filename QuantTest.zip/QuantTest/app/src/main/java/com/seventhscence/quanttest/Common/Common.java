package com.seventhscence.quanttest.Common;

import com.seventhscence.quanttest.Model.Category;

public class Common {
    public static Category selectedCategory=new Category();

}
