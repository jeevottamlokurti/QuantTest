package com.seventhscence.quanttest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;

import com.seventhscence.quanttest.Adapter.CategoryAdapter;
import com.seventhscence.quanttest.Common.SpaceDecoration;
import com.seventhscence.quanttest.DBHelper.DBHelper;

public class MainActivity extends AppCompatActivity {
Toolbar toolbar;
RecyclerView recyclerView_category;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar=(Toolbar)findViewById(R.id.toolbar);



        recyclerView_category=(RecyclerView)findViewById(R.id.recycler_category);
        recyclerView_category.setHasFixedSize(true);
        recyclerView_category.setLayoutManager(new GridLayoutManager(this,2));


        CategoryAdapter adapter=new CategoryAdapter(MainActivity.this, DBHelper.getInstance(this).getAllCategory());
        int spaceInPixel=4;
        recyclerView_category.addItemDecoration(new SpaceDecoration(spaceInPixel));
        recyclerView_category.setAdapter(adapter);
    }
}
